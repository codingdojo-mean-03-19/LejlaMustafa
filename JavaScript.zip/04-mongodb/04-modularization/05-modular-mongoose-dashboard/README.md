# Instructions

Delete your `node_modules` directory from the Mongoose Dashboard assignment.

Copy remaining files here.

Modularize.
