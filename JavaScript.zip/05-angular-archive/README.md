# Instructions

`ng new` from the root of a given chapter.

## Example

Assuming your current working directory is: `03-component-data`  
Issue the following: `ng new dojo-mail`

### _All Archive assignments are optional_
