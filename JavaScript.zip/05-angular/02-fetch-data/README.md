# Assignments List

1. Restful Tasks
2. API
3. Books API
