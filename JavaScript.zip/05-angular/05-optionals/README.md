# Assigments List (Optionals)

1. Attribute Directives
2. @Input/@Output
3. Form Validations

## Use these techniques to modify existing assignments
