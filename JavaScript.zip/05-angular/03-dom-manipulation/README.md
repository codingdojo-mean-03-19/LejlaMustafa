# Assignments List

1. Restful Tasks Continued
2. Restful Tasks Interactive
3. Ninja Gold (Group Activity -- Self Assigned)
4. Restful Tasks CRUD
5. Restful Tasks Nested
6. Rate My Cakes
