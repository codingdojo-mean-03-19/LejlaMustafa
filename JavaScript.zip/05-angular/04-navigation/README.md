# Assignments List

1. Weather API
2. Shinto Coins (Optional)
3. Authors
4. Route Tree
5. Product Manager
6. Quote Ranks
