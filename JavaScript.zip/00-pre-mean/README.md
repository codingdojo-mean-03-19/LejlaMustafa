Pre-MEAN content only valid for Online Full-Time Students
