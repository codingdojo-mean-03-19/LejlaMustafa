# Instructions

`ng new` from the root of a given chapter.

## Example

Assuming your current working directory is: `01-integration`  
Issue the following: `ng new anonymous-notes`
