# Assignments List

1. Anonymous Notes
2. Team Manager
3. Github Battle
4. Bicycle Marketplace (Belt Reviewer)
